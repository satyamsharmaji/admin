<footer>
		<div class="container">
			<ul class="list-inline text-center">
				<li><a href="#">Terms Of Use</a></li>
				<li><a href="#">Privacy Policy</a></li>
				<li><a href="#">Results Disclosure</a></li>
				<li><a href="#">FAQ</a></li>
				<li><a href="#">Refund Policy</a></li>
				<li><a href="#">Earnings Disclaimer</a></li>
				<li><a href="#">Contact Us</a></li>
			</ul>
			<p class="text-center">Copyright © 2018 XTREAM MARKETTING CODE. All Right Reserved</p>
		</div>
	</footer>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo  get_template_directory_uri().'-child'; ?>/js/bootstrap.min.js"></script>
    <script src="<?php echo  get_template_directory_uri().'-child'; ?>/js/customscript.js"></script>
	<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
	
	<script src="https://cdn.datatables.net/responsive/2.2.1/js/dataTables.responsive.min.js"></script>
	<script src="https://cdn.datatables.net/responsive/2.2.1/js/responsive.bootstrap.min.js"></script>
	
	


	<script>
		$(document).ready(
			function(){
			$('.dropdown-button').click(function(){
				$('.dropdown-options').toggle();
			});
			
			$('.earning-btn').click(function(){
				$('.earning-ddown').fadeToggle();
			});
			$('.lead-btn').click(function(){
				$('.lead-ddown').fadeToggle();
			});
			$('.referral-btn').click(function(){
				$('.referral-ddown').fadeToggle();
			});
			$('#phone_name_list').DataTable();
			
			$('#list_all_contact').DataTable();
		});
	</script>
  </body>
</html>