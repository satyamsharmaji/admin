<?php
if(isset($_GET['sub_more_page'])){

    if($_GET['sub_more_page'] == 'view_phone_list'){
        include( get_template_directory() . '-child/admin/ringless-voicemail/view_phone_list.php' );
    }

}
else{
include( get_template_directory() . '-child/admin/header.php' );


?>
<!-- Create List Model popup-->



<!-- End Create List Model popup-->

</div>
        <section class="dashboard">
		<div class="container">
			<div class="dashboard-box">
				<div class="row">
					<div class="col-md-9 col-sm-9 col-lg-9 col-xs-12">
						<h3 class="list_heading">Phone List<a href="#" id="create_list" class="btn btn-primary pull-right" data-toggle="modal" data-target="#myModal">Create List</a></h3>
                        <table class="table table-striped" id="phone_name_list">
                            <thead>
                                <tr>
                                <th scope="col">S. No.</th>
                                <th scope="col">List Name</th>
                                <th scope="col">Number of contacts</th>
                                <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                            global $wpdb;
                                $table_name = $wpdb->prefix.'ringless_voice_mail';
                                $query = "SELECT * FROM $table_name WHERE status = 1";
                                $result = $wpdb->get_results( $query,ARRAY_A);
                                $serial = 1;
                                foreach($result as $data)
                                {
                                    $count_contact = explode(',',$data['contacts']);
                                   
                                    
                            ?>
                                <tr>
                                    <th scope="row"><?php echo $serial;?></th>
                                    <td><?php echo $data['list_name']?></td>
                                    <td><?php  if($data['contacts'] == '') { echo '0';} else{ echo count($count_contact); }?></td>
                                    <td>
                                        <a href="<?php echo $_SERVER['REQUEST_URI'];?>&sub_more_page=view_phone_list&list_id=<?php echo $data['id'];?>" class="btn btn-primary">View</a>
                                        <span class="btn btn-info">Rename</span>
                                        <span class="btn btn-danger">Delete</span>
                                        <span class="btn btn-warning">Disable</span>
                                    </td>
                                </tr>
                                <?php
                            $serial++;
                            } ?>
                                
                            </tbody>
                        </table>
						
					</div>
					<div class="col-md-3 col-sm-3 col-lg-3 col-xs-12">
						<div class="user-info">
                        <?php
                         
                           
                            
                        ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
    <!-- Modal -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Create List</h4>
            </div>
            <div class="modal-body">
               
                <form action="" method="post">
                    <div class="form-group">
                        <label for="text">Enter List Name:</label>
                        <input type="text" class="form-control" name="list_name">
                        
                    </div>
                    <input type="submit" class="btn btn-primary" name="save_name" value="Submit">
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                
            </div>
            </div>
        </div>
    </div>
<?php
include( get_template_directory() . '-child/admin/footer.php' );

if(isset($_POST['save_name'])){

    global $post;

    $table = $wpdb->prefix.'ringless_voice_mail';
    $data = array(
                'list_name' => $_POST['list_name'],
                  
            );
    $wpdb->insert( $table, $data );
	echo '<script>window.location.href="'.home_url().'/dashboard/?page=ringless_voice_mail"</script>';
}
}
?>