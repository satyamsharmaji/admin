<?php
if(isset($_GET['sub-page'])){

	if($_GET['sub-page'] == 'phone_list'){

		include( get_template_directory() . '-child/admin/ringless-voicemail/phone_list.php' );

	}
}
else{
	include( get_template_directory() . '-child/admin/header.php' );

?>

	<section class="dashboard">
		<div class="container">
			<div class="dashboard-box">
				<div class="row">
					<div class="col-md-9 col-sm-9 col-lg-9 col-xs-12">
						
						<div class="row">
							<h3 style="border-bottom: 1px solid #ca1302;color: #ca1302;padding-bottom: 15px">Compaign Managment</h3>
						</div>
						<div class="dashboard-short">
							<div class="row">
								<div class="col-md-6 col-sm-6 col-lg-6 col-xs-12">
									<a href="#">
										<div class="dashboard-inner">
											<div class="icon-shadow">
												<i class="fa fa-volume-up"></i>
											</div>
											<div class="dashboard-content">
												<h4>All Audio List</h4>
											</div>
										</div>
									</a>
								</div>
								<div class="col-md-6 col-sm-6 col-lg-6 col-xs-12">
									<a href="<?php echo home_url();?>/dashboard/?page=ringless_voice_mail&sub-page=phone_list">
										<div class="dashboard-inner">
											<div class="icon-shadow">
												<i class="fa fa-phone-square"></i>
											</div>
											<div class="dashboard-content">
												<h4>All Contact List</h4>
											</div>
										</div>
									</a>
								</div>
								
								
								
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-3 col-lg-3 col-xs-12">
						<div class="user-info">
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	

<?php
include( get_template_directory() . '-child/admin/footer.php' );
}

?>