<?php


include( get_template_directory() . '-child/admin/header.php' );

global $wpdb;
$table_name = $wpdb->prefix.'ringless_voice_mail';

$list_id = $_GET['list_id'];
$detail =  $wpdb->get_row("SELECT * FROM $table_name WHERE id = $list_id",ARRAY_A);

$contacts = explode(",",$detail['contacts']);
// print_r($contacts);
$serial = 1;
?>
<!-- Create List Model popup-->



<!-- End Create List Model popup-->

</div>
        <section class="dashboard">
		<div class="container">
			<div class="dashboard-box">
				<div class="row">
					<div class="col-md-12 col-sm-12 col-lg-12 col-xs-12">
						<h3 class="list_heading"><?php echo $detail['list_name'];?> Contacts
                        <a href="#" id="create_list"  style="margin-left:25px;" class="btn btn-primary pull-right" data-toggle="modal" data-target="#add_new_number">Add New Number</a>
                        
                        <a href="#" id="create_list" class="btn btn-success pull-right" data-toggle="modal" data-target="#upload_csv_file">Upload File</a>
                        </h3>
                        <table class="table table-striped" id="list_all_contact">
                            <thead>
                                <tr>
                                <th scope="col">S. No.</th>
                                <th scope="col">All Contacts</th>
                                <th scope="col">Update Contact</th>
                                <th scope="col">Delete Contact</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                           
                               
                               
                                foreach($contacts as $contact)
                                {
                                   
                                   
                                    
                            ?>
                           <?php if($contact != ''){ ?>
                                <tr>
                                    <th scope="row"><?php echo $serial;?></th>
                                    <td><?php echo $contact;?></td>
                                    <td>
                                        <span class="btn btn-info up_pop" id="<?php echo $contact;?>">Update</span>
                                        
                                    </td>
                                    <td>
                                        <a href="<?php echo $_SERVER['REQUEST_URI'];?>&del_contact=<?php echo $contact;?>" onclick="return confirm('Are You Sure');" class="btn btn-danger">Delete</span>
                                        
                                    </td>
                                </tr>
                           <?php }
                          
                            $serial++;
                            } ?>
                                
                            </tbody>
                        </table>
						
					</div>
					
				</div>
			</div>
		</div>
	</section>

    <!-- Add New Number Modal -->

    <div class="modal fade" id="add_new_number" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Add New Number</h4>
            </div>
            <div class="modal-body">
               
                <form action="" method="post">
                    <div class="form-group">

                        <input type="text" class="form-control" name="contact_number" placeholder="Enter Number">
                        
                    </div>
                    <input type="submit" class="btn btn-primary" name="save_name" value="Submit">
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                
            </div>
            </div>
        </div>
    </div>
    <!-- END Add New Number Modal -->

    <!-- Add New Number Modal -->
        <div class="modal fade" id="upload_csv_file" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">Upload CSV FILE</h4>
                </div>
                <div class="modal-body">
                
                    <form action="" method="post" enctype="multipart/form-data">
                        <div class="form-group">

                            <input type="file"  name="csv_file">
                            
                        </div>
                        <input type="submit" class="btn btn-primary" name="upload_csv" value="Submit">
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    
                </div>
                </div>
            </div>
        </div>
    <!-- END Add New Number Modal -->

    <!-- Update Modal Box -->

    <div class="update_modalbox" style="display: none;">
        <div class="update_header">
            Update Contact
        </div>
            <form action="" method="post" enctype="multipart/form-data">
                        <div class="form-group">

                            <input type="text"  name="contact_up" id="upconval" readonly style="width:100%;padding:3px;">
                            
                        </div>
                         <div class="form-group">

                            <input type="text"  name="new_contact_up" placeholder="Enter New Number" style="width:100%;padding:3px;">
                            
                        </div>
                        <input type="submit" class="btn btn-primary" name="update_con" value="Update">
            </form>
            <div class="updatefooter">
                
                    <span class="pull-right btn btn-default" id="clo_it">Close</span>
                
            </div>
        </div>

    <!-- END Update Modal Box -->

<?php
include( get_template_directory() . '-child/admin/footer.php' );

if(isset($_POST['save_name'])){

    $data = array(
        'contacts' => $_POST['contact_number'].','.$detail['contacts'],
    );
    $where = array(
        'id'    => $list_id,
    );
    $wpdb->update( $table_name, $data, $where );
    echo '<script>window.location.href="'.$_SERVER['REQUEST_URI'].'"</script>';

}

/* Upload Csv Options*/

if(isset($_POST['upload_csv'])){

    
    $check_exe = explode(".", $_FILES['csv_file']['name']);
    
    if($check_exe[1] != 'csv'){
        echo '<script>alert("Please upload only CSV file")</script>';
    }
    else{
    
   $content = file_get_contents($_FILES['csv_file']['tmp_name']);
   $csvData = $content;
    $lines = explode(PHP_EOL, $csvData);
    $array = array();
    foreach ($lines as $line) {
        $array[] = str_getcsv($line);
    }
    echo '<pre>';
   
    $singleArray = array();

    foreach ($array as $key => $value){
        $singleArray[$key] = $value[0];
    }
    
    $a = count($singleArray);
    $new_array = array();
    $b = 0;
    for($i=1; $i < $a; $i++){
        $new_array[$b] =$singleArray[$i]; 
        $b++;
    }
    $new_contact = implode(",",$new_array);

    $data = array(
        'contacts' => $new_contact.','.$detail['contacts'],
    );
    $where = array(
        'id'    => $list_id,
    );
    $wpdb->update( $table_name, $data, $where );
    echo '<script>window.location.href="'.$_SERVER['REQUEST_URI'].'"</script>';
    
    }
}

if(isset($_POST['update_con'])){
    
    $new_contacts = array();
    $new_contacts = $contacts;
    $position = array_search($_POST['contact_up'], $new_contacts);
    $new_contacts[$position] = $_POST['new_contact_up'];

         $data = array(
        'contacts' => implode(",",$new_contacts),
        );
        $where = array(
            'id'    => $list_id,
        );
        $wpdb->update( $table_name, $data, $where );
        echo '<script>window.location.href="'.$_SERVER['REQUEST_URI'].'"</script>';

    
}

if(isset($_GET['del_contact'])){
    
    $new_contacts = array();
    $new_contacts = $contacts;
    $position = array_search($_GET['del_contact'], $new_contacts);
    unset($new_contacts[$position]);
    $data = array(
    'contacts' => implode(",",$new_contacts),
    );
    $where = array(
        'id'    => $list_id,
    );
    $wpdb->update( $table_name, $data, $where );

    echo '<script>window.location.href="'.home_url().'/dashboard/?page=ringless_voice_mail&sub-page=phone_list&sub_more_page=view_phone_list&list_id='.$list_id.'"</script>';

}
?>
 