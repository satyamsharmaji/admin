<?php
/*
Template Name: Dashboard
*/

if(isset($_GET['page'])){

	if($_GET['page'] == 'ringless_voice_mail'){

		include( get_template_directory() . '-child/admin/ringless-voicemail/ringless_voice_mail.php' );

	}
	if($_GET['page'] == 'view_phone_list'){

		include( get_template_directory() . '-child/admin/ringless-voicemail/view_phone_list.php' );

	}
}
else{

	include( get_template_directory() . '-child/admin/header.php' );
?>

	<section class="dashboard">
		<div class="container">
			<div class="dashboard-box">
				<div class="row">
					<div class="col-md-9 col-sm-9 col-lg-9 col-xs-12">
						<div class="custom-dropdown">
							<div class="dropdown-button">
								ACCOUNT OVERVIEW
								<span class="fa fa-angle-down pull-right"></span>
							</div>
							<div class="dropdown-options">
								<ul>
									<li><a href="#">Some Option</a></li>
									<li><a href="#">Other Option</a></li>
								</ul>
							</div>
						</div>
						<div class="row">
							<div class="col-md-4 col-sm-4 col-lg-4 col-xs-12">
								<div class="small-boxes">
									<div class="small-box bg-aqua">
										<div class="inner">
										  <h3>$2,137.00</h3>

										  <p>EARNINGS</p>
										</div>
										<div class="icon">
										  <i class="fa fa-line-chart"></i>
										</div>
										<a href="javascript: void(0);" class="small-box-footer earning-btn">Choose Options <i class="fa fa-arrow-circle-right"></i></a>
										<ul class="options-ddown earning-ddown">
											<li><a href="#">Day</a></li>
											<li><a href="#">Week</a></li>
											<li><a href="#">Month</a></li>
											<li><a href="#">Quarter</a></li>
											<li><a href="#">Year</a></li>
										</ul>
									  </div>
								</div>
							</div>
							<div class="col-md-4 col-sm-4 col-lg-4 col-xs-12">
								<div class="small-boxes">
									<div class="small-box bg-aqua">
										<div class="inner">
										  <h3>48</h3>

										  <p>LEADS</p>
										</div>
										<div class="icon">
										  <i class="fa fa-users"></i>
										</div>
										<a href="javascript: void(0);" class="small-box-footer lead-btn">More info <i class="fa fa-arrow-circle-right"></i></a>
										<ul class="options-ddown lead-ddown">
											<li><a href="#">Option 1</a></li>
											<li><a href="#">Option 2</a></li>
											<li><a href="#">Option 3</a></li>
											<li><a href="#">Option 4</a></li>
											<li><a href="#">Option 5</a></li>
										</ul>
									  </div>
								</div>
							</div>
							<div class="col-md-4 col-sm-4 col-lg-4 col-xs-12">
								<div class="small-boxes">
									<div class="small-box bg-aqua">
										<div class="inner">
										  <h3>34</h3>

										  <p>REFERRALS</p>
										</div>
										<div class="icon">
										  <i class="fa fa-users"></i>
										</div>
										<a href="javascript: void(0);" class="small-box-footer referral-btn">More info <i class="fa fa-arrow-circle-right"></i></a>
										<ul class="options-ddown referral-ddown">
											<li><a href="#">Option 1</a></li>
											<li><a href="#">Option 2</a></li>
											<li><a href="#">Option 3</a></li>
											<li><a href="#">Option 4</a></li>
											<li><a href="#">Option 5</a></li>
										</ul>
									  </div>
								</div>
							</div>
						</div>
						<div class="dashboard-short">
							<div class="row">
								<div class="col-md-6 col-sm-6 col-lg-6 col-xs-12">
									<a href="#">
										<div class="dashboard-inner">
											<div class="icon-shadow">
												<i class="fa fa-envelope"></i>
											</div>
											<div class="dashboard-content">
												<h4>SMS and Voice Broadcast</h4>
											</div>
										</div>
									</a>
								</div>
								<div class="col-md-6 col-sm-6 col-lg-6 col-xs-12">
									<a href="<?php echo home_url();?>/dashboard/?page=ringless_voice_mail">
										<div class="dashboard-inner">
											<div class="icon-shadow">
												<i class="fa fa-phone-square"></i>
											</div>
											<div class="dashboard-content">
												<h4>Ringless Voicemail</h4>
											</div>
										</div>
									</a>
								</div>
								<div class="col-md-6 col-sm-6 col-lg-6 col-xs-12">
									<a href="#">
										<div class="dashboard-inner">
											<div class="icon-shadow">
												<i class="fa fa-line-chart"></i>
											</div>
											<div class="dashboard-content">
												<h4>Capture and Sales</h4>
											</div>
										</div>
									</a>
								</div>
								<div class="col-md-6 col-sm-6 col-lg-6 col-xs-12">
									<a href="#">
										<div class="dashboard-inner">
											<div class="icon-shadow">
												<i class="fa fa-share"></i>
											</div>
											<div class="dashboard-content">
												<h4>Auto Responder</h4>
											</div>
										</div>
									</a>
								</div>
								<div class="col-md-6 col-sm-6 col-lg-6 col-xs-12">
									<a href="#">
									<div class="dashboard-inner">
										<div class="icon-shadow">
											<i class="fa fa-camera"></i>
										</div>
										<div class="dashboard-content">
											<h4>Capture Page Builder</h4>
										</div>
									</div>
									</a>
								</div>
								<div class="col-md-6 col-sm-6 col-lg-6 col-xs-12">
									<a href="#">
										<div class="dashboard-inner">
											<div class="icon-shadow">
												<i class="fa fa-handshake-o"></i>
											</div>
											<div class="dashboard-content">
												<h4>Reseller Licence</h4>
											</div>
										</div>
									</a>
								</div>
								<div class="col-md-6 col-sm-6 col-lg-6 col-xs-12">
									<a href="#">
										<div class="dashboard-inner">
											<div class="icon-shadow">
												<i class="fa fa-wrench"></i>
											</div>
											<div class="dashboard-content">
												<h4>Software</h4>
											</div>
										</div>
									</a>
								</div>
								<div class="col-md-6 col-sm-6 col-lg-6 col-xs-12">
									<a href="#">
										<div class="dashboard-inner">
											<div class="icon-shadow">
												<i class="fa fa-rss"></i>
											</div>
											<div class="dashboard-content">
												<h4>Subscription</h4>
											</div>
										</div>
									</a>
								</div>
								<div class="col-md-6 col-sm-6 col-lg-6 col-xs-12">
									<a href="#">
										<div class="dashboard-inner">
											<div class="icon-shadow">
												<i class="fa fa-cog"></i>
											</div>
											<div class="dashboard-content">
												<h4>Setting</h4>
											</div>
										</div>
									</a>
								</div>
								<div class="col-md-6 col-sm-6 col-lg-6 col-xs-12">
									<a href="#">
										<div class="dashboard-inner">
											<div class="icon-shadow">
												<i class="fa fa-play"></i>
											</div>
											<div class="dashboard-content">
												<h4>Marketting Banners</h4>
											</div>
										</div>
									</a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-3 col-lg-3 col-xs-12">
						<div class="user-info">
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	<?php

	include( get_template_directory() . '-child/admin/header.php' );

	 }
	?>