<?php
/*
Template Name: Login Form
*/
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Registration</title>

    <!-- Bootstrap -->
    <link href="<?php echo  get_template_directory_uri().'-child'; ?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://use.fontawesome.com/releases/v5.0.7/css/all.css" rel="stylesheet">
    <link href="<?php echo  get_template_directory_uri().'-child'; ?>/css/pricing.css" rel="stylesheet">
    <link href="<?php echo  get_template_directory_uri().'-child'; ?>/css/registeration.css" rel="stylesheet">
    <link href="<?php echo  get_template_directory_uri().'-child'; ?>/css/responsive.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
	<section class="registeration">
        <div class="site_logo">
            <img src="<?php echo home_url();?>/wp-content/uploads/2017/12/Xtreme_marketing_Code_Logo.jpg" alt="">
        </div>
	    <div class="container">
			<div class="col-md-4">
			</div>
			<div class="col-md-4">
				<div class="login_area">
				<h3>Login</h3>
					<form action="" method="post">
					  <div class="form-group">
						<p><label>Username or Email</label></p>
						<input type="email" name="email" class="form-control" id="exampleInputEmail1" placeholder="Email">
					  </div>
					  <div class="form-group">			
						<p><label>Password</label><i style="float: right; color: #f00;">Forget Your Password</i></p>
						<input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
					  </div>
					 <input type="submit" name="submit" value="Submit" class="submit_login">
					  <div class="popup-footer"><p>Don't have an account? <a href="javasript: void(0)" data-toggle="modal" data-target="#registerModal">Sign up</a></p></div>
					</form>
				</div>
			</div>
			<div class="col-md-4">
			</div>
		</div>
</section>
</body>
</html>
<?php
if(isset($_POST['submit'])){
    
    $email = $_POST['email'];
    $password = $_POST['password'];
    global $wpdb;

    $table_name = $wpdb->prefix.'register_user';
    $query = "SELECT * FROM $table_name WHERE email = '$email' AND password = '$password'";
    $result = $wpdb->get_row($query,ARRAY_A);
    if(count($result) > 0){
        echo '<script>alert("You have Logged In"); window.location.href="'.home_url().'/dashboard/"</script>';
    }
    else{
        echo '<script>alert("User Name and Password is incorrect."); window.location.href="'.$_SERVER['HTTP_REFERER'].'"</script>';
    }
}
?>